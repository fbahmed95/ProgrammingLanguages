Zaryab Farooq, 913282371, zfarooq@ucdavis.edu
Fareeha Ahmed, 999307283, fbahmed@ucdavis.edu

All test cases are passed. 