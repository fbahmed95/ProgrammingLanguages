#include <stdio.h>
int main() {int x_0i;x_0i = 1001;for(int i=0; i<10; i++){x_0i = x_0i + 3;printf("%d\n", x_0i);}printf("%d\n", 2);}