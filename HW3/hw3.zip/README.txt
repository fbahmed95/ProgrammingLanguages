Fareeha Ahmed, 999307283, fbaahmed@ucdavis.edu, fbahmed
Zaryab Farooq, 913282371, zfarooq@ucdavis.edu, zaryab30

All parts are working!
