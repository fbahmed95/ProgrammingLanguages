Zaryab Farooq, 913282371, zfarooq@ucdavis.edu, zaryab30
Fareeha Ahmed, 999307283, fbahmed@ucdavis.edy, fbahmed 



In part 2, swap_prefix_suffix(K, L, S) is not working. 
Everything else is correct.
