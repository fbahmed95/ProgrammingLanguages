#include <stdio.h>
int main() {int x_0i;x_0i = 3;for(int i=0; i<10; i++){printf("%d\n", 3);}}