public abstract class Element{
    
    public abstract void Print();
}