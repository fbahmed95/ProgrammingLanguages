#include <stdio.h>
int main() {int x_0i;x_0i = 3;for(int i=0; i<10; i++){if(x_0i<=0){printf("%d\n", 100);}else{printf("%d\n", 69);}printf("%d\n", 3);}}