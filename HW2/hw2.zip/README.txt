Fareeha Ahmed, 999307283
Zaryab Farooq, 913282371

All parts Working!

For Part5 ----> BNF:

    for::= '&' expr block '$'

We picked this BNF because it was simple, easy to understand and 
mimicked the 'do' BNF rule.